package com.qiniu.storage.model;

/**
 * Created by bailong on 15/2/22.
 */
public class BatchStatus {
    public int code;
}
