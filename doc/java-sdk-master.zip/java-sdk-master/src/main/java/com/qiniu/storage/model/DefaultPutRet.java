package com.qiniu.storage.model;

public class DefaultPutRet {
    public String hash;
    public String key;
}
